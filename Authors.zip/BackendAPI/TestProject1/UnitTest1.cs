using BooksAPI.Contexts;
using BooksAPI.Domains;
using BooksAPI.Repositories;
using Microsoft.EntityFrameworkCore;


namespace TestProject1
{
    public class UnitTest1
    {
        [Fact]
        public void List_GetBooks_AllBooks()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<Context>()
            .UseInMemoryDatabase(databaseName: "BooksList")
            .Options;

            using (var context = new Context(options))
            {
                context.Books.Add(new Book { BookId = 1, Name = "Harry Potter", PublicationYear = "1943", Pages = "96", AuthorId = 1 });
                context.Books.Add(new Book { BookId = 2, Name = "Crepusculo", PublicationYear = "2008", Pages = "311", AuthorId = 2 });
                context.Books.Add(new Book { BookId = 3, Name = "Senhor dos Aneis", PublicationYear = "1956", Pages = "456", AuthorId = 3 });
                context.SaveChanges();
            }

            using (var context = new Context(options))
            {
                // Act 
                BookRepository bookRepository = new(context);
                List<Book> listBooks = bookRepository.List();

                // Assert 
                Assert.Equal(3, listBooks.Count);
                Assert.Equal("Harry Potter", listBooks[0].Name);
                Assert.Equal("1943", listBooks[0].PublicationYear);
                Assert.Equal("96", listBooks[0].Pages);
                Assert.Equal("Crepusculo", listBooks[1].Name);
                Assert.Equal("2008", listBooks[1].PublicationYear);
                Assert.Equal("311", listBooks[1].Pages);
                Assert.Equal("Senhor dos Aneis", listBooks[2].Name);
                Assert.Equal("1956", listBooks[2].PublicationYear);
                Assert.Equal("456", listBooks[2].Pages);
            }
        }


        [Fact]
        public void Create_AddNewBook_BookCreated()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<Context>()
                .UseInMemoryDatabase(databaseName: "Books")
                .Options;

            Book newBook = new()
            {
                Name = "Novo livro"
            };

            using (var context = new Context(options))
            {
                BookRepository bookRepository = new(context);

                // Act
                var bookCreated = bookRepository.Create(newBook);

                // Assert
                Assert.Equal(newBook, bookCreated);
                Assert.Equal("Novo livro", bookCreated.Name);
            }
        }









    }
}