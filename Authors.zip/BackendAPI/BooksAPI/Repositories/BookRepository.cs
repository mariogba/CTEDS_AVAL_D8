﻿using BooksAPI.Contexts;
using BooksAPI.Domains;
using BooksAPI.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace BooksAPI.Repositories;

public class BookRepository : IBook
{
    private readonly Context ctx;

	public BookRepository(Context ctx)
	{
		this.ctx = ctx;
	}

    public Book Create(Book newBook)
    {
        var ctxResponse = ctx.Books.Add(newBook);
        ctx.SaveChanges();
        return ctxResponse.Entity;
    }

    public List<Book> List()
    {
        return ctx.Books.ToList();
    }
}
