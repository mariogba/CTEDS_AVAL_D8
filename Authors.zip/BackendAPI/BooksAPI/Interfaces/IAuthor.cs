﻿using BooksAPI.Domains;

namespace BooksAPI.Interfaces;

public interface IAuthor
{
    List<Author> List();

    void Create(Author newAuthor);    
}
