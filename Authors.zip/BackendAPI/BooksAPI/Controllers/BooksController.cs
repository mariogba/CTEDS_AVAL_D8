﻿using BooksAPI.Contexts;
using BooksAPI.Domains;
using BooksAPI.Interfaces;
using BooksAPI.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace BooksAPI.Controllers;

[Route("api/[controller]")]
[ApiController]
public class BooksController : ControllerBase
{
    private IBook BooksRepository { get; set; }

    public BooksController(Context ctx)
    {
        BooksRepository = new BookRepository(ctx);
    }

    [HttpGet]
    public IActionResult List()
    {
        return Ok(BooksRepository.List());
    }

    [HttpPost]
    public IActionResult Create(Book newBook)
    {
        return Ok(BooksRepository.Create(newBook));
    }

}

